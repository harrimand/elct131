function [Vcap] = capScope(Vsig, t, R, C)
% capScope(Vsig, t, R, C) returns capacitor voltage waveform
% Parameters:
%   Vsig:  Signal waveform vector applied to capacitor
%   t: Time Step Vector for signal waveform
%   R: Series resistance value
%   C: Capacitor Value in Farads
%
%   See also: sqWave, TriWave, SinWav, Vcap, xRange, yRange, Dxtick, Dytick

    Vcap = [0];
    dT = t(2) - t(1);
    rc = R * C;
    for ts = 2:length(t)
        if Vsig(ts) > Vcap(end)
            dV = Vsig(ts) - Vcap(end);
            dVcap = dV * (1 - exp(-dT / rc));
            Vcap = [Vcap, dVcap + Vcap(end)];
        elseif Vsig(ts) < Vcap(end)
            dV = Vcap(end) - Vsig(ts);
            dVcap = dV * exp(-dT / rc);
            %Vcap = [Vcap, Vcap(end) - dVcap];
            Vcap = [Vcap, Vsig(ts) + dVcap];
        else
            dVcap = Vcap(end);
            Vcap = [Vcap, dVcap];
        end
    end
end
