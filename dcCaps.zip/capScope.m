## Author: Darrell Harriman harrimand@gmail.com
## Created: 2018-10-08

function [Vcap] = capScope(Vsig, t, R, C)
% capScope(Vsig, t, R, C) returns capacitor voltage waveform
% Parameters:
%   Vsig:  Signal waveform vector applied to capacitor
%   t: Time Step Vector for signal waveform
%   R: Series resistance value
%   C: Capacitor Value in Farads
%
%   See also: sqWave, TriWave, SinWav, Vcap, xRange, yRange, Dxtick, Dytick

    Vcap = [0];
    dT = t(2) - t(1);
    rc = R * C;
    for ts = 2:length(t)
        if Vsig(ts) > Vcap(end)
            dV = Vsig(ts) - Vcap(end);
            dVcap = dV * (1 - exp(-dT / rc));
            Vcap = [Vcap, dVcap + Vcap(end)];
        elseif Vsig(ts) < Vcap(ts - 1)
            dV = Vcap(ts-1) - Vsig(ts);
            dVcap = dV * exp(-dT / rc);
            Vcap = [Vcap, dVcap];
        else
            dVcap = Vcap(ts-1);
            Vcap = [Vcap, dVcap];
        endif
    endfor
end
