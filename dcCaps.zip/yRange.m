function yRange(fig, minY, maxY, yStep)
% yRange(fig, minY, maxY, yStep) 
% Set Y Axis min and max scale on figure(fig)
% Parameters:
%     fig: figure # (window) to apply Y axis range to
%     minY: minimum Y asis value
%     maxY: maximum Y asis value
%     yStep: Optional yStep requires file Dytick.m to set y tick spacing
%
% See also: xRange, Dxtick, Dytick
  figure(fig);
  set(gca, 'ylim', [minY, maxY]);
  if nargin == 4
    Dytick(fig, yStep);
  end
  grid off
  % plot([0, 0], [minY, maxY], 'LineWidth', 2); %Plot line on Y Axis @ 0
end
