function [t sqW] = sqWave(F, pw, amplitude, spc, duration)
% sqWave returns vectors t and pwm signal
% [t sqW] = sqWave(F, pw, amplitude, spc, duration)
% F = frequency
% pw = Pulse Width
% amplitude = High Level  (Low Level = 0)
% spc = Samples Per Cycle
% duration = Signal duration in seconds
%
% See also: TriWave, SinWav

  T = 1/F;
  t = 0:1/(F * spc):duration;
  sqW = ((t-floor(t/T)*T)<pw)*amplitude;
end;
  