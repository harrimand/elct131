function Dytick(fig, tickSize)
% Dytick(fig, tickSize) sets tick time interval on Y axis
% Parameters:
%     fig:  Figure# (window) where yAxis will be updated
%     tickSize: tick interval
%
% See also: Dxtick, xRange, yRange

  figure(fig);
  yRange = get(gca, 'ylim');
  yMin = yRange(1);
  yMax = yRange(2);
 
  yTick = yMin+mod(abs(yMin),tickSize):tickSize:yMax-mod(abs(yMax),tickSize);
  
  set(gca, 'ytick', []);
  set(gca, 'YMinorGrid', 'off');
  
  set(gca, 'ytick', yTick);
  set(gca, 'YMinorGrid', 'off');
  end
  