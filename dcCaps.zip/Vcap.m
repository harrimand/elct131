
function Vc = Vcap(V, t, R, C)
    Vc = V .* (1 - exp(-t / (R * C)));
endfunction
