function Vc = Vcap(V, t, R, C)
% Vc = Vcap(V, t, R, C) Returns Capacitor voltage at given time t.
% Parameters:
%   V: Voltage applied to the Capacitor
%       If V < 0 calculate discharge voltage
%   t: Capacitor charge time
%   R: Series resistor value
%   C: Capacitor value in Farads
%
% See also: capScope, sqWave
    if V > 0
        Vc = V .* (1 - exp(-t / (R * C)));
    elseif V < 0
        Vc = abs(V) * exp(-t / (R * C));
    else
        Vc = V;
end
