function xRange(fig, minX, maxX, xStep)
% xRange(fig, minX, maxX, xStep) 
% Set X Axis min and max scale on figure(fig)
% Parameters:
%     fig: figure # (window) to apply X axis range to
%     minX: minimum X asis value
%     maxX: maximum X asis value
%     xStep: Optional xStep requires file Dxtick.m to set x tick spacing
%
% See also: yRange, Dxtick, Dytick

  figure(fig);
  set(gca, 'xlim', [minX, maxX]);
  if nargin == 4
    Dxtick(fig, xStep);
  end
end
