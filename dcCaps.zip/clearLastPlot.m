% Clear last plot while leaving grid lines, x Axis and y Axis lines.  

function clearLastPlot(fig=1)
% clearLastPlot(fig) clears last plot on figure
% Parameters:
%    fig: figure # where last plot will be cleared
    figure(fig);
    h = findobj('type', 'line');
    if length(h) > 2
        delete(h(1));
    end
end
